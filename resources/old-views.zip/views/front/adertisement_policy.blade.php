@extends('layouts.front.app')

@section('title')
<title>Adertisement Policy</title>
@endsection

@section('content')
    <h1>Adertisement Policy</h1>
@endsection