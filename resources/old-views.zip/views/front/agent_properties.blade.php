@extends('layouts.front.app')

@section('title')
<title>Agent Properties</title>
@endsection

@section('content')
    <h1>Agent Properties</h1>
@endsection