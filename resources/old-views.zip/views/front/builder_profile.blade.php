@extends('layouts.front.app')

@section('title')
<title>Builder Profile</title>
@endsection

@section('content')
    <h1>Builder Profile</h1>
@endsection