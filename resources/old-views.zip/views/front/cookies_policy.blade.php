@extends('layouts.front.app')

@section('title')
<title>Cookies Policy</title>
@endsection

@section('content')
    <h1>Hello</h1>
@endsection