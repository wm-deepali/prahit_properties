@extends('layouts.front.app')

@section('title')
<title>Refund & Cancellation Policy</title>
@endsection

@section('content')
    <h1>Refund & Cancellation Policy</h1>
@endsection