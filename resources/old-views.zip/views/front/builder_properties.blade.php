@extends('layouts.front.app')

@section('title')
<title>Builder Properties</title>
@endsection

@section('content')
    <h1>Builder Properties</h1>
@endsection