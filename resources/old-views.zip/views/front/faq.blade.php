@extends('layouts.front.app')

@section('title')
<title>FAQ</title>
@endsection

@section('content')
    <h1>FAQ</h1>
@endsection